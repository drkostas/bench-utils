from .timeit import timeit
from .profileit import profileit

__author__ = "drkostas"
__email__ = "georgiou.kostas94@gmail.com"
__version__ = "0.0.1"
